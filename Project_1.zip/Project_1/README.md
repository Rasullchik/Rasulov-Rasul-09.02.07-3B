# DriveNow — Инструкция по установке

## Требования
- PHP 7.4+
- MySQL 5.7+ / MariaDB 10.3+
- Веб-сервер (Apache / Nginx) или XAMPP / OpenServer

## Установка

### 1. Создать базу данных
```bash
mysql -u root -p < install.sql
```
Или открыть `install.sql` в phpMyAdmin и выполнить.

### 2. Настроить подключение
Открыть `config/database.php` и указать свои данные:
```php
define('DB_USER', 'root');   // ваш логин MySQL
define('DB_PASS', '');       // ваш пароль MySQL
```

### 3. Разместить файлы
Скопировать всю папку проекта в корень веб-сервера:
- XAMPP: `C:/xampp/htdocs/drivenow/`
- OpenServer: `domains/drivenow/`

### 4. Открыть в браузере
```
http://localhost/drivenow/
```

## Структура проекта
```
├── index.html          — главная страница
├── styles.css          — стили
├── script.js           — фронтенд (работает через API)
├── functions.php       — общие PHP-функции
├── install.sql         — скрипт создания БД
├── api/
│   ├── register.php    — регистрация
│   ├── login.php       — вход
│   ├── logout.php      — выход
│   ├── get_user.php    — текущий пользователь
│   ├── get_cars.php    — список автомобилей
│   ├── get_garage.php  — гараж пользователя
│   ├── add_to_garage.php
│   ├── update_garage.php
│   ├── delete_garage.php
│   └── update_profile.php — настройки профиля
├── config/
│   └── database.php    — подключение к БД
└── data/               — папка для данных
```
