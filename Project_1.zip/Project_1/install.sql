-- DriveNow — скрипт создания базы данных
-- Запустить: mysql -u root -p < install.sql

CREATE DATABASE IF NOT EXISTS drivenow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE drivenow;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS garage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    car_id INT NOT NULL,
    custom_name VARCHAR(100) NOT NULL,
    hours_booked INT NOT NULL DEFAULT 1,
    status ENUM('Активна','Завершена') NOT NULL DEFAULT 'Активна',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
