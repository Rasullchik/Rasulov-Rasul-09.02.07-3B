<?php
// Подключаем все вспомогательные функции
require_once __DIR__ . '/../functions.php';

// Устанавливаем заголовок — ответ будет в формате JSON
header('Content-Type: application/json; charset=utf-8');

// Разрешаем только POST-запросы
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'error' => 'Метод не поддерживается'], 405);
}

// Читаем и декодируем JSON из тела запроса
$data     = json_decode(file_get_contents('php://input'), true) ?? [];

// Извлекаем данные из запроса, убираем пробелы где нужно
$username = trim($data['username'] ?? '');   // Логин
$password = $data['password'] ?? '';         // Пароль (пробелы не убираем)
$password2= $data['password2'] ?? '';        // Повтор пароля для проверки
$fullName = trim($data['full_name'] ?? '');  // Полное имя
$email    = trim($data['email'] ?? '');      // Email

// Валидация всех полей — собираем ошибки в массив
$errors = [];

// Проверяем логин
$e = validateUsername($username);
if ($e) $errors['username'] = $e;

// Проверяем пароль
$e = validatePassword($password);
if ($e) $errors['password'] = $e;

// Проверяем email
$e = validateEmail($email);
if ($e) $errors['email'] = $e;

// Проверяем полное имя
$e = validateFullName($fullName);
if ($e) $errors['full_name'] = $e;

// Проверяем что пароли совпадают (только если пароль не пустой)
if ($password && $password !== $password2) {
    $errors['password2'] = 'Пароли не совпадают';
}

// Если есть хотя бы одна ошибка — отправляем их клиенту
if ($errors) {
    jsonResponse(['success' => false, 'errors' => $errors], 422);
}

// Проверяем уникальность логина и email в базе данных
$pdo = getDB();

// Ищем пользователя с таким же логином ИЛИ email
$stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
$stmt->execute([$username, $email]);
$existing = $stmt->fetch();

// Если найден — определяем что именно занято
if ($existing) {
    // Проверяем занят ли логин
    $stmt2 = $pdo->prepare('SELECT id FROM users WHERE username = ?');
    $stmt2->execute([$username]);

    if ($stmt2->fetch()) {
        // Логин занят
        jsonResponse(['success' => false, 'errors' => ['username' => 'Этот логин уже занят']], 409);
    }

    // Если логин свободен, значит занят email
    jsonResponse(['success' => false, 'errors' => ['email' => 'Этот email уже зарегистрирован']], 409);
}

// Все проверки пройдены — создаём пользователя в базе
$userId = saveUser($username, $password, $fullName, $email);

// Запускаем сессию и сразу авторизуем нового пользователя
startSecureSession();
$_SESSION['user_id'] = $userId;

// Отправляем успешный ответ с данными нового пользователя
jsonResponse([
    'success' => true,
    'user' => [
        'id'        => $userId,              // ID нового пользователя
        'username'  => h($username),         // Логин — экранируем
        'full_name' => h($fullName),         // Полное имя — экранируем
        'email'     => h($email),            // Email — экранируем
    ]
]);
