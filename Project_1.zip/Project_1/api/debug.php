<?php
// ДИАГНОСТИКА — удали этот файл после отладки!
require_once __DIR__ . '/../functions.php';

header('Content-Type: application/json; charset=utf-8');

startSecureSession();

$dbOk = false;
$dbError = '';
try {
    getDB();
    $dbOk = true;
} catch (Exception $e) {
    $dbError = $e->getMessage();
}

echo json_encode([
    'session_id'   => session_id(),
    'session_data' => $_SESSION ?? [],
    'cookies'      => array_keys($_COOKIE),
    'user_id'      => getCurrentUserId(),
    'db_ok'        => $dbOk,
    'db_error'     => $dbError,
    'php_version'  => PHP_VERSION,
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
