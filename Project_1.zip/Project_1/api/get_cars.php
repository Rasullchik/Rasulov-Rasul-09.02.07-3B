<?php
// Список доступных автомобилей — статичные данные, авторизация не требуется

// Устанавливаем заголовок — ответ будет в формате JSON
header('Content-Type: application/json; charset=utf-8');

// Массив всех доступных автомобилей
// Каждый элемент — ассоциативный массив с характеристиками автомобиля
$cars = [
    // id — уникальный идентификатор автомобиля
    // brand — марка, model — модель
    // pricePerHour — цена аренды в рублях за час
    // category — категория: Эконом / Комфорт / Бизнес
    // isElectric — true если электромобиль
    // imageUrl — путь к изображению автомобиля
    ['id'=>1,  'brand'=>'BMW',        'model'=>'3 Series', 'pricePerHour'=>850,  'category'=>'Бизнес',  'isElectric'=>false, 'imageUrl'=>'images/cars/bmw.png'],
    ['id'=>2,  'brand'=>'Tesla',      'model'=>'Model 3',  'pricePerHour'=>950,  'category'=>'Бизнес',  'isElectric'=>true,  'imageUrl'=>'images/cars/tesla.png'],
    ['id'=>3,  'brand'=>'Kia',        'model'=>'Rio',      'pricePerHour'=>280,  'category'=>'Эконом',  'isElectric'=>false, 'imageUrl'=>'images/cars/rio.png'],
    ['id'=>4,  'brand'=>'Hyundai',    'model'=>'Solaris',  'pricePerHour'=>300,  'category'=>'Эконом',  'isElectric'=>false, 'imageUrl'=>'images/cars/hunday.png'],
    ['id'=>5,  'brand'=>'Toyota',     'model'=>'Camry',    'pricePerHour'=>550,  'category'=>'Комфорт', 'isElectric'=>false, 'imageUrl'=>'images/cars/toyota-camry.jpg'],
    ['id'=>6,  'brand'=>'Volkswagen', 'model'=>'Polo',     'pricePerHour'=>320,  'category'=>'Эконом',  'isElectric'=>false, 'imageUrl'=>'images/cars/volkswagen-polo.jpg'],
    ['id'=>7,  'brand'=>'Tesla',      'model'=>'Model Y',  'pricePerHour'=>1100, 'category'=>'Бизнес',  'isElectric'=>true,  'imageUrl'=>'images/cars/tesla-model-y.jpg'],
    ['id'=>8,  'brand'=>'Skoda',      'model'=>'Octavia',  'pricePerHour'=>420,  'category'=>'Комфорт', 'isElectric'=>false, 'imageUrl'=>'images/cars/skoda-octavia.jpg'],
    ['id'=>9,  'brand'=>'Nissan',     'model'=>'Leaf',     'pricePerHour'=>380,  'category'=>'Комфорт', 'isElectric'=>true,  'imageUrl'=>'images/cars/nissan-leaf.jpg'],
    ['id'=>10, 'brand'=>'Mercedes',   'model'=>'E-Class',  'pricePerHour'=>1200, 'category'=>'Бизнес',  'isElectric'=>false, 'imageUrl'=>'images/cars/mercedes-e-class.jpg'],
    ['id'=>11, 'brand'=>'Renault',    'model'=>'Logan',    'pricePerHour'=>260,  'category'=>'Эконом',  'isElectric'=>false, 'imageUrl'=>'images/cars/renault-logan.jpg'],
    ['id'=>12, 'brand'=>'Audi',       'model'=>'A4',       'pricePerHour'=>780,  'category'=>'Бизнес',  'isElectric'=>false, 'imageUrl'=>'images/cars/audi-a4.jpg'],
];

// Кодируем массив в JSON и отправляем клиенту
// JSON_UNESCAPED_UNICODE — кириллица передаётся как есть, без \uXXXX-кодов
echo json_encode(['success' => true, 'cars' => $cars], JSON_UNESCAPED_UNICODE);
