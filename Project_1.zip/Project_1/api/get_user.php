<?php
// Подключаем вспомогательные функции
require_once __DIR__ . '/../functions.php';

// Устанавливаем заголовок — ответ будет в формате JSON
header('Content-Type: application/json; charset=utf-8');

// Пытаемся получить ID текущего пользователя из сессии или куки
$uid = getCurrentUserId();

// Если пользователь не авторизован — возвращаем null (не ошибку, это нормальная ситуация)
if (!$uid) {
    jsonResponse(['success' => true, 'user' => null]);
}

// Ищем пользователя в базе данных по ID
$user = findUserById($uid);

// Если пользователь не найден в базе (например был удалён) — возвращаем null
if (!$user) {
    jsonResponse(['success' => true, 'user' => null]);
}

// Отправляем данные авторизованного пользователя
// h() экранирует строки от XSS
jsonResponse([
    'success' => true,
    'user' => [
        'id'        => $user['id'],           // ID (число, экранирование не нужно)
        'username'  => h($user['username']),  // Логин — экранируем
        'full_name' => h($user['full_name']), // Полное имя — экранируем
        'email'     => h($user['email']),     // Email — экранируем
    ]
]);
