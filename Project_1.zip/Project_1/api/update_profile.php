<?php
// Подключаем вспомогательные функции
require_once __DIR__ . '/../functions.php';

// Устанавливаем заголовок — ответ будет в формате JSON
header('Content-Type: application/json; charset=utf-8');

// Разрешаем только POST-запросы
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'error' => 'Метод не поддерживается'], 405);
}

// Проверяем авторизацию — если не авторизован, вернёт 401 и остановит скрипт
$uid  = requireAuth();

// Читаем и декодируем JSON из тела запроса
$data = json_decode(file_get_contents('php://input'), true) ?? [];

// Определяем тип запроса: 'profile' (имя/email) или 'password' (смена пароля)
$type = $data['type'] ?? '';

// ===== ОБНОВЛЕНИЕ ПРОФИЛЯ (имя и email) =====
if ($type === 'profile') {
    // Извлекаем новое полное имя
    $fullName = trim($data['full_name'] ?? '');

    // Извлекаем новый email
    $email    = trim($data['email'] ?? '');

    // Массив для сбора ошибок валидации
    $errors   = [];

    // Проверяем полное имя
    $e = validateFullName($fullName);
    if ($e) $errors['full_name'] = $e;

    // Проверяем email
    $e = validateEmail($email);
    if ($e) $errors['email'] = $e;

    // Если есть ошибки — отправляем их клиенту
    if ($errors) jsonResponse(['success' => false, 'errors' => $errors], 422);

    // Проверяем что новый email не занят другим пользователем
    $pdo  = getDB();

    // Ищем пользователя с таким email, исключая текущего пользователя (AND id != ?)
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
    $stmt->execute([$email, $uid]);

    // Если нашли другого пользователя с таким email — возвращаем ошибку
    if ($stmt->fetch()) {
        jsonResponse(['success' => false, 'errors' => ['email' => 'Этот email уже используется']], 409);
    }

    // Обновляем профиль в базе данных
    updateUserProfile($uid, $fullName, $email);

    // Отправляем успешный ответ с обновлёнными данными (экранируем от XSS)
    jsonResponse(['success' => true, 'full_name' => h($fullName), 'email' => h($email)]);

// ===== СМЕНА ПАРОЛЯ =====
} elseif ($type === 'password') {
    // Извлекаем текущий пароль для проверки
    $oldPwd  = $data['old_password'] ?? '';

    // Извлекаем новый пароль
    $newPwd  = $data['new_password'] ?? '';

    // Извлекаем повтор нового пароля
    $newPwd2 = $data['new_password2'] ?? '';

    // Получаем данные пользователя (без пароля — findUserById его не возвращает)
    $user = findUserById($uid);

    // Делаем отдельный запрос чтобы получить хеш пароля
    $pdo  = getDB();
    $stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
    $stmt->execute([$uid]);
    $row  = $stmt->fetch();

    // Проверяем что текущий пароль верный
    // password_verify() безопасно сравнивает пароль с bcrypt-хешем
    if (!$row || !password_verify($oldPwd, $row['password_hash'])) {
        jsonResponse(['success' => false, 'errors' => ['old_password' => 'Неверный текущий пароль']], 401);
    }

    // Проверяем новый пароль на соответствие требованиям
    $e = validatePassword($newPwd);
    if ($e) jsonResponse(['success' => false, 'errors' => ['new_password' => $e]], 422);

    // Проверяем что новый пароль и его повтор совпадают
    if ($newPwd !== $newPwd2) {
        jsonResponse(['success' => false, 'errors' => ['new_password2' => 'Пароли не совпадают']], 422);
    }

    // Обновляем пароль в базе данных (функция сама хеширует)
    updateUserPassword($uid, $newPwd);

    // Отправляем успешный ответ
    jsonResponse(['success' => true]);

// ===== НЕИЗВЕСТНЫЙ ТИП ЗАПРОСА =====
} else {
    // Тип не 'profile' и не 'password' — возвращаем ошибку
    jsonResponse(['success' => false, 'error' => 'Неверный тип запроса'], 422);
}
