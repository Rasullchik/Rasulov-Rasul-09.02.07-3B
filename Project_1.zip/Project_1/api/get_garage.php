<?php
// Подключаем вспомогательные функции
require_once __DIR__ . '/../functions.php';

// Устанавливаем заголовок — ответ будет в формате JSON
header('Content-Type: application/json; charset=utf-8');

// Проверяем авторизацию — если не авторизован, функция сама вернёт 401 и остановит скрипт
$uid = requireAuth();

// Получаем все записи гаража текущего пользователя из базы данных
$entries = getGarageByUser($uid);

// Обрабатываем каждую запись: приводим типы и экранируем строки
$safe = array_map(function($e) {
    return [
        'id'          => (int)$e['id'],           // ID записи — приводим к числу
        'carId'       => (int)$e['car_id'],        // ID автомобиля — приводим к числу
        'customName'  => h($e['custom_name']),     // Название — экранируем от XSS
        'hoursBooked' => (int)$e['hours_booked'],  // Количество часов — приводим к числу
        'status'      => h($e['status']),          // Статус — экранируем от XSS
    ];
}, $entries);

// Отправляем список записей гаража клиенту
jsonResponse(['success' => true, 'garage' => $safe]);
