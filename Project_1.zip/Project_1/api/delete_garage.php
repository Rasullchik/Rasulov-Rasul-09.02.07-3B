<?php
// Подключаем вспомогательные функции
require_once __DIR__ . '/../functions.php';

// Устанавливаем заголовок — ответ будет в формате JSON
header('Content-Type: application/json; charset=utf-8');

// Разрешаем только POST-запросы
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'error' => 'Метод не поддерживается'], 405);
}

// Проверяем авторизацию — если не авторизован, вернёт 401 и остановит скрипт
$uid  = requireAuth();

// Читаем и декодируем JSON из тела запроса
$data = json_decode(file_get_contents('php://input'), true) ?? [];

// Извлекаем ID записи которую нужно удалить
$entryId = (int)($data['id'] ?? 0);

// Проверяем что ID положительный
if ($entryId < 1) {
    jsonResponse(['success' => false, 'error' => 'Неверный ID'], 422);
}

// Удаляем запись из базы данных
// Функция проверяет что запись принадлежит текущему пользователю ($uid) — нельзя удалить чужую запись
$ok = deleteGarageEntry($entryId, $uid);

// Если запись не найдена или принадлежит другому пользователю — возвращаем 404
if (!$ok) {
    jsonResponse(['success' => false, 'error' => 'Запись не найдена или нет доступа'], 404);
}

// Отправляем успешный ответ
jsonResponse(['success' => true]);
