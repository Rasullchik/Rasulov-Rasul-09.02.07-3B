<?php
// Подключаем все вспомогательные функции (валидация, работа с БД, сессии)
require_once __DIR__ . '/../functions.php';

// Устанавливаем заголовок — ответ будет в формате JSON с кодировкой UTF-8
header('Content-Type: application/json; charset=utf-8');

// Разрешаем только POST-запросы — GET и другие методы не допускаются
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'error' => 'Метод не поддерживается'], 405);
}

// Читаем тело запроса (JSON) и декодируем в массив
// ?? [] — если тело пустое или не JSON, используем пустой массив
$data     = json_decode(file_get_contents('php://input'), true) ?? [];

// Извлекаем логин, убираем пробелы по краям
$username = trim($data['username'] ?? '');

// Извлекаем пароль (пробелы не убираем — они могут быть частью пароля)
$password = $data['password'] ?? '';

// Флаг "Запомнить меня" — true если передан и не пустой
$remember = !empty($data['remember']);

// Проверяем что логин и пароль не пустые
if (!$username || !$password) {
    jsonResponse(['success' => false, 'error' => 'Введите логин и пароль'], 422);
}

// Ищем пользователя в базе данных по логину
$user = findUserByUsername($username);

// Проверяем: пользователь существует И пароль совпадает с хешем в базе
// password_verify() безопасно сравнивает пароль с bcrypt-хешем
if (!$user || !password_verify($password, $user['password_hash'])) {
    // Намеренно не уточняем что именно неверно — логин или пароль
    jsonResponse(['success' => false, 'error' => 'Неверный логин или пароль'], 401);
}

// Запускаем сессию с безопасными настройками
startSecureSession();

// Генерируем новый ID сессии — защита от session fixation атаки
session_regenerate_id(true);

// Сохраняем ID пользователя в сессии — теперь он авторизован
$_SESSION['user_id'] = $user['id'];

// Обрабатываем опцию «Запомнить меня»
if ($remember) {
    // Создаём токен на основе логина и email пользователя
    $token = hash('sha256', $user['username'] . $user['email']);

    // Устанавливаем куку на 30 дней
    // Параметры: имя, значение, время истечения, путь, домен, secure, httponly
    setcookie('dn_remember', $user['id'] . ':' . $token, time() + 30 * 24 * 3600, '/', '', false, true);
}

// Отправляем успешный ответ с данными пользователя
// h() экранирует данные от XSS перед отправкой клиенту
jsonResponse([
    'success' => true,
    'user' => [
        'id'        => $user['id'],           // ID пользователя (число, экранирование не нужно)
        'username'  => h($user['username']),  // Логин — экранируем HTML-символы
        'full_name' => h($user['full_name']), // Полное имя — экранируем HTML-символы
        'email'     => h($user['email']),     // Email — экранируем HTML-символы
    ]
]);
