<?php
// Подключаем вспомогательные функции
require_once __DIR__ . '/../functions.php';

// Устанавливаем заголовок — ответ будет в формате JSON
header('Content-Type: application/json; charset=utf-8');

// Разрешаем только POST-запросы
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'error' => 'Метод не поддерживается'], 405);
}

// Проверяем авторизацию — если не авторизован, вернёт 401 и остановит скрипт
$uid  = requireAuth();

// Читаем и декодируем JSON из тела запроса
$data = json_decode(file_get_contents('php://input'), true) ?? [];

// Извлекаем ID автомобиля и приводим к целому числу
$carId      = (int)($data['carId'] ?? 0);

// Извлекаем пользовательское название и убираем пробелы по краям
$customName = trim($data['customName'] ?? '');

// Извлекаем количество часов аренды (по умолчанию 1)
$hours      = (int)($data['hoursBooked'] ?? 1);

// Проверяем что ID автомобиля в допустимом диапазоне (у нас 12 автомобилей)
if ($carId < 1 || $carId > 12) {
    jsonResponse(['success' => false, 'error' => 'Неверный автомобиль'], 422);
}

// Проверяем что название не слишком короткое
if (strlen($customName) < 2) {
    jsonResponse(['success' => false, 'error' => 'Название минимум 2 символа'], 422);
}

// Проверяем что количество часов в допустимом диапазоне (от 1 до 720 = 30 дней)
if ($hours < 1 || $hours > 720) {
    jsonResponse(['success' => false, 'error' => 'Часы: от 1 до 720'], 422);
}

// Добавляем запись в гараж и получаем ID новой записи
$newId = addToGarage($uid, $carId, $customName, $hours);

// Отправляем успешный ответ с данными новой записи
jsonResponse([
    'success' => true,
    'entry' => [
        'id'          => $newId,          // ID новой записи в базе
        'carId'       => $carId,          // ID автомобиля
        'customName'  => h($customName),  // Название — экранируем от XSS
        'hoursBooked' => $hours,          // Количество часов
        'status'      => 'Активна',       // Новая запись всегда имеет статус "Активна"
    ]
]);
