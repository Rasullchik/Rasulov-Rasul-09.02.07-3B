<?php
// Подключаем вспомогательные функции
require_once __DIR__ . '/../functions.php';

// Устанавливаем заголовок — ответ будет в формате JSON
header('Content-Type: application/json; charset=utf-8');

// Разрешаем только POST-запросы
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'error' => 'Метод не поддерживается'], 405);
}

// Проверяем авторизацию — если не авторизован, вернёт 401 и остановит скрипт
$uid  = requireAuth();

// Читаем и декодируем JSON из тела запроса
$data = json_decode(file_get_contents('php://input'), true) ?? [];

// Извлекаем ID записи гаража которую нужно обновить
$entryId    = (int)($data['id'] ?? 0);

// Извлекаем новое название записи
$customName = trim($data['customName'] ?? '');

// Извлекаем новое количество часов аренды
$hours      = (int)($data['hoursBooked'] ?? 1);

// Извлекаем новый статус (по умолчанию "Активна")
$status     = $data['status'] ?? 'Активна';

// Проверяем что ID записи положительный
if ($entryId < 1) {
    jsonResponse(['success' => false, 'error' => 'Неверный ID записи'], 422);
}

// Проверяем что название не слишком короткое
if (strlen($customName) < 2) {
    jsonResponse(['success' => false, 'error' => 'Название минимум 2 символа'], 422);
}

// Проверяем что количество часов в допустимом диапазоне
if ($hours < 1 || $hours > 720) {
    jsonResponse(['success' => false, 'error' => 'Часы: от 1 до 720'], 422);
}

// Проверяем что статус один из допустимых значений (whitelist)
if (!in_array($status, ['Активна', 'Завершена'])) {
    jsonResponse(['success' => false, 'error' => 'Неверный статус'], 422);
}

// Обновляем запись в базе данных
// Функция проверяет что запись принадлежит текущему пользователю ($uid)
$ok = updateGarageEntry($entryId, $uid, $customName, $hours, $status);

// Если запись не найдена или принадлежит другому пользователю — возвращаем 404
if (!$ok) {
    jsonResponse(['success' => false, 'error' => 'Запись не найдена или нет доступа'], 404);
}

// Отправляем успешный ответ
jsonResponse(['success' => true]);
