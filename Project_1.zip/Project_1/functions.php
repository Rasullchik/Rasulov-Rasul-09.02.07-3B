<?php
// Подключаем файл с настройками базы данных и функцией getDB()
require_once __DIR__ . '/config/database.php';

// ===== ВАЛИДАЦИЯ =====

/**
 * Проверяет корректность имени пользователя (логина).
 * Возвращает строку с ошибкой или пустую строку если всё ок.
 */
function validateUsername(string $v): string {
    // Убираем пробелы по краям
    $v = trim($v);

    // Логин не может быть короче 3 символов
    if (strlen($v) < 3) return 'Логин минимум 3 символа';

    // Логин не может быть длиннее 50 символов
    if (strlen($v) > 50) return 'Логин максимум 50 символов';

    // Логин может содержать только латинские буквы, цифры и знак подчёркивания
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $v)) return 'Логин может содержать только буквы, цифры и _';

    // Ошибок нет — возвращаем пустую строку
    return '';
}

/**
 * Проверяет корректность пароля.
 * Возвращает строку с ошибкой или пустую строку если всё ок.
 */
function validatePassword(string $v): string {
    // Пароль не может быть короче 6 символов
    if (strlen($v) < 6) return 'Пароль минимум 6 символов';

    // Пароль не может быть длиннее 255 символов
    if (strlen($v) > 255) return 'Пароль слишком длинный';

    // Ошибок нет
    return '';
}

/**
 * Проверяет корректность email-адреса.
 * Возвращает строку с ошибкой или пустую строку если всё ок.
 */
function validateEmail(string $v): string {
    // Убираем пробелы по краям
    $v = trim($v);

    // Email не может быть пустым
    if (empty($v)) return 'Введите email';

    // Проверяем формат email встроенным PHP-фильтром
    if (!filter_var($v, FILTER_VALIDATE_EMAIL)) return 'Некорректный email';

    // Ошибок нет
    return '';
}

/**
 * Проверяет корректность полного имени пользователя.
 * Возвращает строку с ошибкой или пустую строку если всё ок.
 */
function validateFullName(string $v): string {
    // Убираем пробелы по краям
    $v = trim($v);

    // Имя не может быть короче 2 символов
    if (strlen($v) < 2) return 'Имя минимум 2 символа';

    // Имя не может быть длиннее 100 символов
    if (strlen($v) > 100) return 'Имя максимум 100 символов';

    // Ошибок нет
    return '';
}

// ===== ПОЛЬЗОВАТЕЛИ =====

/**
 * Ищет пользователя в базе данных по логину.
 * Возвращает массив с данными пользователя или null если не найден.
 */
function findUserByUsername(string $username): ?array {
    // Получаем соединение с БД
    $pdo = getDB();

    // Готовим параметризованный запрос — защита от SQL-инъекций
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');

    // Выполняем запрос, передавая логин без пробелов по краям
    $stmt->execute([trim($username)]);

    // Получаем одну строку результата
    $row = $stmt->fetch();

    // Если строка найдена — возвращаем её, иначе null
    return $row ?: null;
}

/**
 * Ищет пользователя в базе данных по его ID.
 * Возвращает массив с данными (без пароля) или null если не найден.
 */
function findUserById(int $id): ?array {
    // Получаем соединение с БД
    $pdo = getDB();

    // Запрашиваем только безопасные поля — пароль не включаем
    $stmt = $pdo->prepare('SELECT id, username, full_name, email, created_at FROM users WHERE id = ?');

    // Выполняем запрос с переданным ID
    $stmt->execute([$id]);

    // Получаем одну строку результата
    $row = $stmt->fetch();

    // Если строка найдена — возвращаем её, иначе null
    return $row ?: null;
}

/**
 * Создаёт нового пользователя в базе данных.
 * Возвращает ID только что созданного пользователя.
 */
function saveUser(string $username, string $password, string $fullName, string $email): int {
    // Получаем соединение с БД
    $pdo = getDB();

    // Хешируем пароль алгоритмом bcrypt — никогда не храним пароль в открытом виде
    $hash = password_hash($password, PASSWORD_BCRYPT);

    // Готовим INSERT-запрос для создания пользователя
    $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, full_name, email) VALUES (?, ?, ?, ?)');

    // Выполняем запрос, передавая очищенные данные и хеш пароля
    $stmt->execute([trim($username), $hash, trim($fullName), trim($email)]);

    // Возвращаем ID новой записи как целое число
    return (int)$pdo->lastInsertId();
}

/**
 * Обновляет имя и email пользователя в базе данных.
 */
function updateUserProfile(int $userId, string $fullName, string $email): void {
    // Получаем соединение с БД
    $pdo = getDB();

    // Готовим UPDATE-запрос
    $stmt = $pdo->prepare('UPDATE users SET full_name = ?, email = ? WHERE id = ?');

    // Выполняем запрос с очищенными данными и ID пользователя
    $stmt->execute([trim($fullName), trim($email), $userId]);
}

/**
 * Обновляет пароль пользователя в базе данных.
 */
function updateUserPassword(int $userId, string $newPassword): void {
    // Получаем соединение с БД
    $pdo = getDB();

    // Хешируем новый пароль перед сохранением
    $hash = password_hash($newPassword, PASSWORD_BCRYPT);

    // Готовим UPDATE-запрос для смены пароля
    $stmt = $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?');

    // Выполняем запрос с новым хешем и ID пользователя
    $stmt->execute([$hash, $userId]);
}

// ===== ГАРАЖ =====

/**
 * Возвращает все записи гаража конкретного пользователя.
 * Записи отсортированы от новых к старым.
 */
function getGarageByUser(int $userId): array {
    // Получаем соединение с БД
    $pdo = getDB();

    // Запрашиваем все записи гаража пользователя, сортируем по дате создания (новые первые)
    $stmt = $pdo->prepare('SELECT * FROM garage WHERE user_id = ? ORDER BY created_at DESC');

    // Выполняем запрос с ID пользователя
    $stmt->execute([$userId]);

    // Возвращаем все найденные строки как массив
    return $stmt->fetchAll();
}

/**
 * Добавляет автомобиль в гараж пользователя.
 * Возвращает ID новой записи.
 */
function addToGarage(int $userId, int $carId, string $customName, int $hours): int {
    // Получаем соединение с БД
    $pdo = getDB();

    // Готовим INSERT-запрос для добавления записи в гараж
    $stmt = $pdo->prepare('INSERT INTO garage (user_id, car_id, custom_name, hours_booked) VALUES (?, ?, ?, ?)');

    // Выполняем запрос с данными новой записи
    $stmt->execute([$userId, $carId, trim($customName), $hours]);

    // Возвращаем ID новой записи
    return (int)$pdo->lastInsertId();
}

/**
 * Обновляет запись гаража (название, часы, статус).
 * Проверяет что запись принадлежит именно этому пользователю.
 * Возвращает true если запись была обновлена, false если не найдена.
 */
function updateGarageEntry(int $entryId, int $userId, string $customName, int $hours, string $status): bool {
    // Получаем соединение с БД
    $pdo = getDB();

    // Готовим UPDATE-запрос — условие AND user_id = ? защищает от изменения чужих записей
    $stmt = $pdo->prepare('UPDATE garage SET custom_name = ?, hours_booked = ?, status = ? WHERE id = ? AND user_id = ?');

    // Выполняем запрос с новыми данными
    $stmt->execute([trim($customName), $hours, $status, $entryId, $userId]);

    // rowCount() > 0 означает что хотя бы одна строка была изменена
    return $stmt->rowCount() > 0;
}

/**
 * Удаляет запись из гаража.
 * Проверяет что запись принадлежит именно этому пользователю.
 * Возвращает true если запись была удалена, false если не найдена.
 */
function deleteGarageEntry(int $entryId, int $userId): bool {
    // Получаем соединение с БД
    $pdo = getDB();

    // Готовим DELETE-запрос — условие AND user_id = ? защищает от удаления чужих записей
    $stmt = $pdo->prepare('DELETE FROM garage WHERE id = ? AND user_id = ?');

    // Выполняем запрос
    $stmt->execute([$entryId, $userId]);

    // rowCount() > 0 означает что строка была удалена
    return $stmt->rowCount() > 0;
}

// ===== СЕССИЯ =====

/**
 * Запускает PHP-сессию с безопасными настройками куки.
 * Вызывается перед любой работой с $_SESSION.
 */
function startSecureSession(): void {
    // Запускаем сессию только если она ещё не запущена
    if (session_status() === PHP_SESSION_NONE) {
        // httponly — куку нельзя прочитать через JavaScript (защита от XSS)
        // samesite Lax — куку не отправляют при кросс-сайтовых запросах (защита от CSRF)
        session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);

        // Запускаем сессию
        session_start();
    }
}

/**
 * Возвращает ID текущего авторизованного пользователя.
 * Проверяет сессию, а если её нет — проверяет куку "Запомнить меня".
 * Возвращает null если пользователь не авторизован.
 */
function getCurrentUserId(): ?int {
    // Убеждаемся что сессия запущена
    startSecureSession();

    // Если в сессии есть user_id — пользователь уже авторизован
    if (!empty($_SESSION['user_id'])) {
        return (int)$_SESSION['user_id'];
    }

    // Проверяем куки «Запомнить меня» — если пользователь закрыл браузер
    if (!empty($_COOKIE['dn_remember'])) {
        // Кука хранится в формате "userId:token" — разбиваем на части
        $parts = explode(':', $_COOKIE['dn_remember'], 2);

        // Проверяем что кука содержит ровно две части
        if (count($parts) === 2) {
            // Извлекаем ID пользователя из первой части
            $userId = (int)$parts[0];

            // Извлекаем токен из второй части
            $token  = $parts[1];

            // Ищем пользователя в базе по ID
            $user   = findUserById($userId);

            // Проверяем пользователя и сравниваем токен безопасным способом (защита от timing-атак)
            if ($user && hash_equals(hash('sha256', $user['username'] . $user['email']), $token)) {
                // Токен валиден — восстанавливаем сессию
                $_SESSION['user_id'] = $userId;
                return $userId;
            }
        }

        // Кука невалидна — удаляем её (устанавливаем время истечения в прошлом)
        setcookie('dn_remember', '', time() - 3600, '/', '', false, true);
    }

    // Пользователь не авторизован
    return null;
}

/**
 * Проверяет авторизацию и возвращает ID пользователя.
 * Если пользователь не авторизован — отправляет HTTP 401 и завершает скрипт.
 */
function requireAuth(): int {
    // Пытаемся получить ID текущего пользователя
    $uid = getCurrentUserId();

    // Если пользователь не авторизован — отвечаем ошибкой и останавливаем выполнение
    if ($uid === null) {
        http_response_code(401); // 401 Unauthorized
        echo json_encode(['success' => false, 'error' => 'Необходима авторизация']);
        exit;
    }

    // Возвращаем ID авторизованного пользователя
    return $uid;
}

// ===== HELPERS =====

/**
 * Отправляет JSON-ответ клиенту и завершает выполнение скрипта.
 * Принимает массив данных и HTTP-код ответа (по умолчанию 200).
 */
function jsonResponse(array $data, int $code = 200): void {
    // Устанавливаем HTTP-код ответа
    http_response_code($code);

    // Устанавливаем заголовок Content-Type чтобы браузер знал что получает JSON
    header('Content-Type: application/json; charset=utf-8');

    // Кодируем массив в JSON, JSON_UNESCAPED_UNICODE — не экранировать кириллицу
    echo json_encode($data, JSON_UNESCAPED_UNICODE);

    // Завершаем выполнение скрипта — ничего после этого не выполнится
    exit;
}

/**
 * Экранирует специальные HTML-символы в строке.
 * Защищает от XSS при выводе пользовательских данных.
 * Например: <script> превращается в &lt;script&gt;
 */
function h(string $s): string {
    // ENT_QUOTES — экранировать и одинарные и двойные кавычки
    // ENT_SUBSTITUTE — заменять невалидные символы вместо ошибки
    // UTF-8 — кодировка строки
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
