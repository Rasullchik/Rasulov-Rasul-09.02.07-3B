<?php
// Хост базы данных (обычно localhost при локальной разработке)
define('DB_HOST', 'localhost');

// Название базы данных
define('DB_NAME', 'drivenow');

// Имя пользователя MySQL
define('DB_USER', 'root');      // замените на своего пользователя MySQL

// Пароль пользователя MySQL
define('DB_PASS', '');          // замените на свой пароль MySQL

// Кодировка соединения — utf8mb4 поддерживает все Unicode-символы включая эмодзи
define('DB_CHARSET', 'utf8mb4');

/**
 * Возвращает единственный экземпляр PDO-соединения с базой данных.
 * Использует паттерн Singleton — соединение создаётся один раз и переиспользуется.
 */
function getDB(): PDO {
    // Статическая переменная сохраняет значение между вызовами функции
    static $pdo = null;

    // Если соединение ещё не создано — создаём его
    if ($pdo === null) {
        // Формируем строку подключения DSN (Data Source Name)
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

        // Настройки поведения PDO
        $options = [
            // Бросать исключения при ошибках SQL вместо тихого провала
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,

            // Возвращать строки как ассоциативные массивы ['column' => 'value']
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,

            // Отключить эмуляцию подготовленных запросов — использовать настоящие prepared statements
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            // Создаём PDO-соединение с переданными параметрами
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Если подключение не удалось — возвращаем HTTP 500 и JSON с ошибкой
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Ошибка подключения к базе данных']);
            exit; // Останавливаем выполнение скрипта
        }
    }

    // Возвращаем готовое соединение
    return $pdo;
}
