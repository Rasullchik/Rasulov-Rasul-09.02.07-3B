/* ===== API helpers ===== */
const API_BASE = (function() {
  // Берём путь к script.js и убираем имя файла — получаем корень проекта
  const scripts = document.querySelectorAll('script[src]');
  for (const s of scripts) {
    if (s.src.includes('script.js')) {
      const url = new URL(s.src);
      return url.pathname.replace(/\/script\.js$/, '');
    }
  }
  return '';
})();

async function apiPost(url, body) {
  try {
    const res = await fetch(API_BASE + '/' + url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(body),
    });
    return res.json();
  } catch (e) {
    console.error('apiPost error:', url, e);
    return { success: false, error: 'Нет соединения с сервером' };
  }
}
async function apiGet(url) {
  try {
    const res = await fetch(API_BASE + '/' + url, { credentials: 'same-origin' });
    return res.json();
  } catch (e) {
    console.error('apiGet error:', url, e);
    return { success: false, error: 'Нет соединения с сервером' };
  }
}

/* ===== STATE ===== */
// carsAvailable загружается с сервера один раз
let carsAvailable = [];
let myCars = [];          // гараж текущего пользователя
let currentUser = null;   // { id, username, full_name, email }

/* ===== CLASSES ===== */
class Car {
  constructor({ id, brand, model, pricePerHour, category, isElectric, imageUrl }) {
    this.id = id; this.brand = brand; this.model = model;
    this.pricePerHour = pricePerHour; this.category = category;
    this.isElectric = isElectric; this.imageUrl = imageUrl;
  }
  getTitle() { return `${this.brand} ${this.model}`; }
  getCategoryBadge() {
    return { 'Эконом': 'economy', 'Комфорт': 'comfort', 'Бизнес': 'business' }[this.category] || 'economy';
  }
  getEmoji() {
    if (this.isElectric) return '⚡🚗';
    return { 'BMW':'🚘','Tesla':'⚡','Mercedes':'🏎️','Audi':'🚙','Toyota':'🚕' }[this.brand] || '🚗';
  }
}

class ElectricCar extends Car {
  constructor(data) { super(data); this.batteryCapacity = data.batteryCapacity || 75; }
  getEmoji() { return '⚡🚗'; }
  getBatteryInfo() { return `Батарея: ${this.batteryCapacity} кВт·ч`; }
}

class FilterSort {
  constructor(cars) { this.cars = cars; }
  apply({ search = '', category = '', onlyElectric = false, sort = '' }) {
    let r = [...this.cars];
    if (search) { const q = search.toLowerCase(); r = r.filter(c => c.brand.toLowerCase().includes(q) || c.model.toLowerCase().includes(q)); }
    if (category) r = r.filter(c => c.category === category);
    if (onlyElectric) r = r.filter(c => c.isElectric);
    if (sort === 'price-asc') r.sort((a,b) => a.pricePerHour - b.pricePerHour);
    else if (sort === 'price-desc') r.sort((a,b) => b.pricePerHour - a.pricePerHour);
    else if (sort === 'brand') r.sort((a,b) => a.brand.localeCompare(b.brand));
    return r;
  }
}

class Modal {
  constructor() {
    this.overlay = document.getElementById('modalOverlay');
    this.contentEl = document.getElementById('modalContent');
    this.closeBtn = document.getElementById('modalClose');
    this.closeBtn.addEventListener('click', () => this.close());
    this.overlay.addEventListener('click', e => { if (e.target === this.overlay) this.close(); });
  }
  open(html) { this.contentEl.innerHTML = html; this.overlay.classList.add('open'); }
  close() { this.overlay.classList.remove('open'); }
}

class ThemeSwitcher {
  constructor() {
    this.btn = document.getElementById('themeToggle');
    this.isLight = localStorage.getItem('theme') === 'light';
    this.apply();
    this.btn.addEventListener('click', () => this.toggle());
  }
  apply() {
    document.body.classList.toggle('light', this.isLight);
    // Sun icon = currently light (click to go dark), Moon icon = currently dark (click to go light)
    this.btn.innerHTML = this.isLight
      ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`
      : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>`;
  }
  toggle() { this.isLight = !this.isLight; localStorage.setItem('theme', this.isLight ? 'light' : 'dark'); this.apply(); }
}

class Counter {
  getCount() { return myCars.length; }
  getTotalCost() {
    return myCars.reduce((sum, e) => {
      const car = carsAvailable.find(c => c.id === e.carId);
      return sum + (car ? car.pricePerHour * e.hoursBooked : 0);
    }, 0);
  }
  getByCategory() {
    const cats = { 'Эконом': 0, 'Комфорт': 0, 'Бизнес': 0 };
    myCars.forEach(e => {
      const car = carsAvailable.find(c => c.id === e.carId);
      if (car && cats[car.category] !== undefined) cats[car.category]++;
    });
    return cats;
  }
}

/* ===== INSTANCES ===== */
const modal = new Modal();
const counter = new Counter();

/* ===== TOAST ===== */
function showToast(msg) {
  let t = document.getElementById('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; t.className = 'toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2500);
}

/* ===== CAR SVG ICONS ===== */
const svgSedan = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/></svg>`;
const svgFront = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"><path d="m21 8-2 2-1.5-3.7A2 2 0 0 0 15.646 5H8.4a2 2 0 0 0-1.903 1.257L5 10 3 8"/><path d="M7 14h.01"/><path d="M17 14h.01"/><rect width="18" height="8" x="3" y="10" rx="2"/><path d="M5 18v2"/><path d="M19 18v2"/></svg>`;
const svgSUV   = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"><path d="M5 17H3a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h13l3 4v6h-2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/><path d="M3 9h13"/></svg>`;
const svgHatch = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/><path d="M16 10V7"/></svg>`;
const carSVGs = { 1:svgSedan,2:svgFront,3:svgHatch,4:svgSedan,5:svgSedan,6:svgHatch,7:svgSUV,8:svgFront,9:svgHatch,10:svgSedan,11:svgSedan,12:svgSedan };

/* ===== CAR CARD HELPERS ===== */
function buildCarObj(data) { return data.isElectric ? new ElectricCar(data) : new Car(data); }

function carCardHTML(carObj, inGarage = false) {
  const badgeClass = `badge-${carObj.getCategoryBadge()}`;
  const svg = carSVGs[carObj.id] || svgSedan;
  const imgContent = carObj.imageUrl
    ? `<div class="car-card__img-wrap"><div class="car-card__svg">${svg}</div><img src="${carObj.imageUrl}" alt="${carObj.getTitle()}" class="car-card__photo" onload="this.classList.add('loaded')" /></div>`
    : `<div class="car-card__img-wrap"><div class="car-card__svg car-card__svg--only">${svg}</div></div>`;
  const electricBadge = carObj.isElectric ? `<span class="badge badge-electric">Электро</span>` : '';
  const batteryInfo = (carObj instanceof ElectricCar) ? `<div class="car-card__battery">${carObj.getBatteryInfo()}</div>` : '';
  const addBtn = inGarage ? '' : `<button class="btn btn-primary btn-sm" onclick="addToGarage(${carObj.id}, this)">В гараж</button>`;
  return `<div class="car-card"><div class="car-card__img">${imgContent}</div><div class="car-card__body"><div class="car-card__title">${carObj.getTitle()}</div><div class="car-card__meta"><span class="badge ${badgeClass}">${carObj.category}</span>${electricBadge}</div>${batteryInfo}<div class="car-card__price">${carObj.pricePerHour.toLocaleString('ru-RU')} ₽ <span>/ час</span></div></div><div class="car-card__actions">${addBtn}<button class="btn btn-secondary btn-sm" onclick="openCalc(${carObj.id})">Калькулятор</button></div></div>`;
}

function garageCardHTML(entry) {
  const car = carsAvailable.find(c => c.id === entry.carId);
  if (!car) return '';
  const carObj = buildCarObj(car);
  const cost = car.pricePerHour * entry.hoursBooked;
  const statusClass = entry.status === 'Активна' ? 'status-active' : 'status-done';
  const imgContent = car.imageUrl
    ? `<img src="${car.imageUrl}" alt="${carObj.getTitle()}" class="garage-card__img" />`
    : `<div class="garage-card__img garage-card__img--placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M5 17H3a2 2 0 01-2-2v-4l2-5h14l2 5v4a2 2 0 01-2 2h-2M5 17a2 2 0 104 0 2 2 0 00-4 0zm10 0a2 2 0 104 0 2 2 0 00-4 0z"/></svg></div>`;
  return `<div class="garage-card">${imgContent}<div class="garage-card__info"><div class="garage-card__name">${entry.customName}</div><div class="garage-card__sub">${carObj.getTitle()} &nbsp;&middot;&nbsp; ${entry.hoursBooked} ч</div><div class="garage-card__cost">${cost.toLocaleString('ru-RU')} ₽</div><span class="status-badge ${statusClass}">${entry.status}</span></div><div class="garage-card__actions"><button class="btn btn-secondary btn-sm" onclick="openEditModal(${entry.id})">Изменить</button><button class="btn btn-danger btn-sm" onclick="deleteCar(${entry.id})">Удалить</button></div></div>`;
}

/* ===== HOME PAGE ===== */
function renderHome() {
  const slides = [
    { num: '01', title: 'Свобода передвижения', text: 'Бери машину когда угодно — без залогов и очередей.' },
    { num: '02', title: 'Электромобили в парке', text: 'Tesla Model 3, Model Y и Nissan Leaf уже ждут тебя.' },
    { num: '03', title: 'Честные цены', text: 'Платишь только за часы. Никаких скрытых комиссий.' },
  ];
  const slidesHTML = slides.map((s,i) => `<div class="slider__slide"><div class="slider__num">${s.num}</div><div class="slider__text"><h2>${s.title}</h2><p>${s.text}</p></div></div>`).join('');
  const dotsHTML = slides.map((_,i) => `<div class="slider__dot ${i===0?'active':''}" onclick="goSlide(${i})"></div>`).join('');

  const features = [
    { icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="3" y="11" width="18" height="11" rx="1"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>`, title:'Без залога', text:'Просто выбери машину и езжай.' },
    { icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>`, title:'Везде в городе', text:'Более 200 точек выдачи.' },
    { icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`, title:'Страховка включена', text:'КАСКО и ОСАГО в стоимости.' },
    { icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/></svg>`, title:'Всё онлайн', text:'Бронирование за 2 минуты.' },
  ];
  const featuresHTML = features.map(f => `<div class="feature-card"><div class="feature-card__icon">${f.icon}</div><h3>${f.title}</h3><p>${f.text}</p></div>`).join('');

  const promos = [
    { tag:'Новым клиентам', title:'Первая поездка −50%', text:'Для новых пользователей. Промокод при регистрации.', code:'FIRST50' },
    { tag:'Электро', title:'Tesla на выходные', text:'Аренда Tesla Model Y на 2 дня по цене 1,5 дней.', code:'TESLA2D' },
    { tag:'Ночной тариф', title:'С 22:00 до 07:00 −30%', text:'Скидка на все автомобили в ночное время.', code:'NIGHT30' },
  ];
  const promosHTML = promos.map(p => `<div class="promo-card"><div class="promo-card__tag">${p.tag}</div><div class="promo-card__title">${p.title}</div><div class="promo-card__text">${p.text}</div><div class="promo-card__code" onclick="copyPromo('${p.code}',this)"><span>Промокод: <strong>${p.code}</strong></span><span class="promo-copy-hint">Скопировать</span></div></div>`).join('');

  const greeting = currentUser
    ? `<p style="margin-top:12px;font-size:1rem;opacity:.85">Добро пожаловать, ${currentUser.full_name.split(' ')[0]}! 👋</p>`
    : `<div class="parallax-btns" style="margin-top:16px"><button class="btn btn-outline" onclick="openAuth('login')">Войти</button><button class="btn btn-primary" onclick="openAuth('register')">Регистрация</button></div>`;

  document.getElementById('app').innerHTML = `
    <div class="parallax-hero" id="parallaxHero">
      <div class="parallax-bg" id="parallaxBg"></div>
      <div class="parallax-content">
        <div class="parallax-tag">Premium Carsharing</div>
        <h1>Езди без<br>ограничений</h1>
        <p>Более 100 автомобилей в вашем городе. Аренда от 260 ₽/час.</p>
        ${greeting}
        <div class="parallax-btns" style="margin-top:12px">
          <button class="btn btn-primary" onclick="navigate('cars')">Смотреть автомобили</button>
          <button class="btn btn-outline" onclick="navigate('garage')">Мой гараж</button>
        </div>
      </div>
      <div class="parallax-scroll-hint">Листай вниз</div>
    </div>
    <div class="home-counters" id="homeCounters">
      <div class="home-counter"><span class="home-counter__val" data-target="100">0</span><span class="home-counter__plus">+</span><div class="home-counter__label">Автомобилей</div></div>
      <div class="home-counter"><span class="home-counter__val" data-target="50000">0</span><span class="home-counter__plus">+</span><div class="home-counter__label">Поездок</div></div>
      <div class="home-counter"><span class="home-counter__val" data-target="200">0</span><span class="home-counter__plus">+</span><div class="home-counter__label">Точек выдачи</div></div>
      <div class="home-counter"><span class="home-counter__val" data-target="4">0</span><span class="home-counter__plus">.8</span><div class="home-counter__label">Рейтинг</div></div>
    </div>
    <div class="section-title">Акции и спецпредложения</div>
    <div class="promos-grid">${promosHTML}</div>
    <div class="slider" id="slider">
      <div class="slider__track" id="sliderTrack">${slidesHTML}</div>
      <button class="slider__btn slider__btn--prev" onclick="shiftSlide(-1)">&#8249;</button>
      <button class="slider__btn slider__btn--next" onclick="shiftSlide(1)">&#8250;</button>
      <div class="slider__dots">${dotsHTML}</div>
    </div>
    <div class="section-title">Почему DriveNow</div>
    <div class="features">${featuresHTML}</div>`;

  initSlider(); initParallax(); animateCounters();
}

function initParallax() {
  const bg = document.getElementById('parallaxBg');
  if (!bg) return;
  const hero = document.getElementById('parallaxHero');
  if (hero) { const pc = document.createElement('div'); pc.className = 'particles'; hero.appendChild(pc); spawnParticles(pc); }
  const handler = () => { if (bg) bg.style.transform = `translateY(${window.scrollY * 0.45}px)`; };
  window.addEventListener('scroll', handler, { passive: true });
  window._parallaxHandler = handler;
}

function animateCounters() {
  document.querySelectorAll('.home-counter__val').forEach(el => {
    const target = parseInt(el.dataset.target), duration = 1600, step = target / (duration / 16);
    let current = 0;
    const timer = setInterval(() => {
      current = Math.min(current + step, target);
      el.textContent = Math.floor(current).toLocaleString('ru-RU');
      if (current >= target) clearInterval(timer);
    }, 16);
  });
}

function copyPromo(code, el) {
  navigator.clipboard.writeText(code).catch(() => {});
  const hint = el.querySelector('.promo-copy-hint');
  hint.textContent = 'Скопировано';
  setTimeout(() => { hint.textContent = 'Скопировать'; }, 2000);
  showToast(`Промокод ${code} скопирован`);
}

let sliderIndex = 0, sliderTotal = 3, sliderTimer = null;
function initSlider() { sliderIndex = 0; sliderTotal = 3; clearInterval(sliderTimer); sliderTimer = setInterval(() => shiftSlide(1), 4000); }
function shiftSlide(dir) { sliderIndex = (sliderIndex + dir + sliderTotal) % sliderTotal; goSlide(sliderIndex); }
function goSlide(i) {
  sliderIndex = i;
  const track = document.getElementById('sliderTrack');
  if (track) track.style.transform = `translateX(-${i * 100}%)`;
  document.querySelectorAll('.slider__dot').forEach((d,idx) => d.classList.toggle('active', idx === i));
}

/* ===== CARS PAGE ===== */
let filterState = { search: '', category: '', onlyElectric: false, sort: '' };

function renderCars() {
  document.getElementById('app').innerHTML = `
    <div class="page-banner page-banner--cars">
      <div class="page-banner__bg"></div>
      <div class="page-banner__content"><h1 class="page-banner__title">Автомобили</h1><p class="page-banner__sub">Выберите идеальный автомобиль для поездки</p></div>
    </div>
    <div class="controls">
      <input class="search-input" id="searchInput" type="text" placeholder="🔍 Поиск по марке или модели..." value="${filterState.search}" oninput="onSearch(this.value)" />
      <select class="select-control" id="catFilter" onchange="onCategory(this.value)">
        <option value="">Все категории</option>
        <option value="Эконом" ${filterState.category==='Эконом'?'selected':''}>Эконом</option>
        <option value="Комфорт" ${filterState.category==='Комфорт'?'selected':''}>Комфорт</option>
        <option value="Бизнес" ${filterState.category==='Бизнес'?'selected':''}>Бизнес</option>
      </select>
      <select class="select-control" id="sortFilter" onchange="onSort(this.value)">
        <option value="">Без сортировки</option>
        <option value="price-asc" ${filterState.sort==='price-asc'?'selected':''}>Цена ↑</option>
        <option value="price-desc" ${filterState.sort==='price-desc'?'selected':''}>Цена ↓</option>
        <option value="brand" ${filterState.sort==='brand'?'selected':''}>По марке</option>
      </select>
      <label style="display:flex;align-items:center;gap:6px;font-size:0.9rem;cursor:pointer">
        <input type="checkbox" id="electricFilter" ${filterState.onlyElectric?'checked':''} onchange="onElectric(this.checked)" /> Только электро
      </label>
    </div>
    <div class="cars-grid" id="carsGrid"></div>`;
  renderCarsGrid();
  initPageBannerParallax();
}

function renderCarsGrid() {
  const filtered = new FilterSort(carsAvailable).apply(filterState);
  const grid = document.getElementById('carsGrid');
  if (!grid) return;
  if (!filtered.length) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><div class="empty-state__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg></div><p>Ничего не найдено</p></div>`;
    return;
  }
  grid.innerHTML = filtered.map(c => carCardHTML(buildCarObj(c))).join('');
}

function onSearch(v) { filterState.search = v; renderCarsGrid(); }
function onCategory(v) { filterState.category = v; renderCarsGrid(); }
function onSort(v) { filterState.sort = v; renderCarsGrid(); }
function onElectric(v) { filterState.onlyElectric = v; renderCarsGrid(); }

async function addToGarage(carId, btn) {
  if (!currentUser) { openAuth('login'); showToast('Войдите, чтобы добавить в гараж'); return; }
  const car = carsAvailable.find(c => c.id === carId);
  if (!car) { showToast('Автомобиль не найден'); return; }
  if (btn) { btn.disabled = true; btn.textContent = '...'; }
  const res = await apiPost('api/add_to_garage.php', { carId, customName: `${car.brand} ${car.model}`, hoursBooked: 1 });
  if (res.success) {
    myCars.push(res.entry);
    showToast(`${car.brand} ${car.model} добавлен в гараж`);
    if (btn) { btn.textContent = '✓ В гараже'; }
  } else {
    showToast(res.error || 'Ошибка');
    if (btn) { btn.disabled = false; btn.textContent = 'В гараж'; }
  }
}

/* ===== CALCULATOR ===== */
function openCalc(carId) {
  const car = carsAvailable.find(c => c.id === carId);
  if (!car) return;
  modal.open(`<h2>Калькулятор аренды</h2><p style="color:var(--text-muted);margin-bottom:20px;font-size:0.82rem;letter-spacing:1px">${car.brand} ${car.model} &nbsp;&middot;&nbsp; ${car.pricePerHour.toLocaleString('ru-RU')} ₽/час</p><div class="form-group"><label>Количество часов</label><input type="number" id="calcHours" class="search-input" min="1" max="720" value="1" oninput="updateCalcResult(${car.pricePerHour})" style="width:100%" /></div><div id="calcResult" class="calc-result">Итого: ${car.pricePerHour.toLocaleString('ru-RU')} ₽</div><div class="modal-actions"><button class="btn btn-secondary" onclick="modal.close()">Закрыть</button></div>`);
}
function updateCalcResult(p) {
  const h = parseInt(document.getElementById('calcHours').value) || 0;
  document.getElementById('calcResult').textContent = `Итого: ${(p * h).toLocaleString('ru-RU')} ₽`;
}

/* ===== GARAGE PAGE ===== */
function renderGarage() {
  if (!currentUser) { navigate('home'); openAuth('login'); showToast('Войдите, чтобы открыть гараж'); return; }
  document.getElementById('app').innerHTML = `
    <div class="page-banner page-banner--garage">
      <div class="page-banner__bg"></div>
      <div class="page-banner__content"><h1 class="page-banner__title">Мой гараж</h1><p class="page-banner__sub">Ваши арендованные автомобили</p></div>
    </div>
    <div id="garageList"></div>`;
  renderGarageList();
  initPageBannerParallax();
}

function renderGarageList() {
  const list = document.getElementById('garageList');
  if (!list) return;
  if (!myCars.length) {
    list.innerHTML = `<div class="empty-state"><div class="empty-state__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg></div><p>Гараж пуст. Добавьте машины на странице «Автомобили».</p></div>`;
    return;
  }
  list.innerHTML = myCars.map(e => garageCardHTML(e)).join('');
}

async function deleteCar(garageId) {
  const res = await apiPost('api/delete_garage.php', { id: garageId });
  if (res.success) {
    myCars = myCars.filter(e => e.id !== garageId);
    renderGarageList();
    showToast('Автомобиль удалён из гаража');
  } else {
    showToast(res.error || 'Ошибка удаления');
  }
}

function openEditModal(garageId) {
  const entry = myCars.find(e => e.id === garageId);
  if (!entry) return;
  modal.open(`
    <h2>Редактировать</h2>
    <div class="form-group"><label>Название</label><input type="text" id="editName" class="search-input" value="${entry.customName}" style="width:100%" oninput="validateField(this,'editName')" /><div class="field-error" id="err-editName"></div></div>
    <div class="form-group"><label>Часов аренды</label><input type="number" id="editHours" class="search-input" min="1" max="720" value="${entry.hoursBooked}" style="width:100%" oninput="validateField(this,'editHours')" /><div class="field-error" id="err-editHours"></div></div>
    <div class="form-group"><label>Статус</label><select id="editStatus" class="select-control" style="width:100%"><option value="Активна" ${entry.status==='Активна'?'selected':''}>Активна</option><option value="Завершена" ${entry.status==='Завершена'?'selected':''}>Завершена</option></select></div>
    <div class="modal-actions"><button class="btn btn-primary" onclick="saveEdit(${garageId})">Сохранить</button><button class="btn btn-secondary" onclick="modal.close()">Отмена</button></div>`);
}

async function saveEdit(garageId) {
  const nameEl = document.getElementById('editName');
  const hoursEl = document.getElementById('editHours');
  const status = document.getElementById('editStatus').value;
  if (!validateField(nameEl,'editName') || !validateField(hoursEl,'editHours')) return;
  const res = await apiPost('api/update_garage.php', { id: garageId, customName: nameEl.value.trim(), hoursBooked: parseInt(hoursEl.value), status });
  if (res.success) {
    const entry = myCars.find(e => e.id === garageId);
    if (entry) { entry.customName = nameEl.value.trim(); entry.hoursBooked = parseInt(hoursEl.value); entry.status = status; }
    modal.close();
    renderGarageList();
    showToast('Изменения сохранены');
  } else {
    showToast(res.error || 'Ошибка сохранения');
  }
}

/* ===== STATS PAGE ===== */
function renderStats() {
  if (!currentUser) { navigate('home'); openAuth('login'); showToast('Войдите, чтобы открыть статистику'); return; }
  const count = counter.getCount();
  const total = counter.getTotalCost();
  const cats = counter.getByCategory();
  const avgHours = count ? (myCars.reduce((s,e) => s + e.hoursBooked, 0) / count).toFixed(1) : 0;
  const maxCat = Object.entries(cats).sort((a,b) => b[1]-a[1])[0];
  const maxVal = Math.max(...Object.values(cats), 1);
  const barsHTML = Object.entries(cats).map(([cat,val]) => `<div class="bar-row"><div class="bar-label">${cat}</div><div class="bar-track"><div class="bar-fill" style="width:${(val/maxVal)*100}%"></div></div><div class="bar-val">${val} шт.</div></div>`).join('');

  document.getElementById('app').innerHTML = `
    <div class="page-banner page-banner--stats">
      <div class="page-banner__bg"></div>
      <div class="page-banner__content"><h1 class="page-banner__title">Статистика</h1><p class="page-banner__sub">Ваши данные об аренде</p></div>
    </div>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-card__value">${count}</div><div class="stat-card__label">Машин в гараже</div></div>
      <div class="stat-card"><div class="stat-card__value">${total.toLocaleString('ru-RU')} ₽</div><div class="stat-card__label">Общая стоимость аренды</div></div>
      <div class="stat-card"><div class="stat-card__value">${avgHours}</div><div class="stat-card__label">Среднее часов на авто</div></div>
      <div class="stat-card"><div class="stat-card__value">${maxCat ? maxCat[0] : '—'}</div><div class="stat-card__label">Популярная категория</div></div>
    </div>
    <div class="chart-bar-wrap"><h3>Распределение по категориям</h3>${barsHTML || '<p style="color:var(--text-muted)">Нет данных</p>'}</div>`;
  initPageBannerParallax();
}

/* ===== SETTINGS PAGE ===== */
function renderSettings() {
  if (!currentUser) { navigate('home'); openAuth('login'); return; }
  document.getElementById('app').innerHTML = `
    <div class="page-banner page-banner--contacts">
      <div class="page-banner__bg"></div>
      <div class="page-banner__content"><h1 class="page-banner__title">Настройки профиля</h1><p class="page-banner__sub">Управление аккаунтом</p></div>
    </div>
    <div class="contacts-grid">
      <div class="contact-form">
        <h2>Личные данные</h2>
        <div class="auth-error" id="profileError" style="display:none"></div>
        <div class="form-success" id="profileSuccess" style="display:none">Данные обновлены</div>
        <div class="form-group"><label>Имя</label><input type="text" id="settingName" class="search-input" value="${currentUser.full_name}" style="width:100%" /></div>
        <div class="form-group"><label>Email</label><input type="email" id="settingEmail" class="search-input" value="${currentUser.email}" style="width:100%" /></div>
        <button class="btn btn-primary" onclick="saveProfile()">Сохранить</button>
      </div>
      <div class="contact-form">
        <h2>Смена пароля</h2>
        <div class="auth-error" id="pwdError" style="display:none"></div>
        <div class="form-success" id="pwdSuccess" style="display:none">Пароль изменён</div>
        <div class="form-group"><label>Текущий пароль</label><input type="password" id="oldPwd" class="search-input" style="width:100%" /></div>
        <div class="form-group"><label>Новый пароль</label><input type="password" id="newPwd" class="search-input" style="width:100%" /></div>
        <div class="form-group"><label>Повторите новый пароль</label><input type="password" id="newPwd2" class="search-input" style="width:100%" /></div>
        <button class="btn btn-primary" onclick="savePassword()">Изменить пароль</button>
      </div>
    </div>`;
  initPageBannerParallax();
}

async function saveProfile() {
  const fullName = document.getElementById('settingName').value.trim();
  const email = document.getElementById('settingEmail').value.trim();
  const errEl = document.getElementById('profileError');
  const okEl = document.getElementById('profileSuccess');
  errEl.style.display = 'none'; okEl.style.display = 'none';
  const res = await apiPost('api/update_profile.php', { type: 'profile', full_name: fullName, email });
  if (res.success) {
    currentUser.full_name = res.full_name;
    currentUser.email = res.email;
    updateAuthBtn();
    okEl.style.display = 'block';
    setTimeout(() => { okEl.style.display = 'none'; }, 3000);
  } else {
    const msg = res.errors ? Object.values(res.errors).join(', ') : (res.error || 'Ошибка');
    errEl.textContent = msg; errEl.style.display = 'block';
  }
}

async function savePassword() {
  const oldPwd = document.getElementById('oldPwd').value;
  const newPwd = document.getElementById('newPwd').value;
  const newPwd2 = document.getElementById('newPwd2').value;
  const errEl = document.getElementById('pwdError');
  const okEl = document.getElementById('pwdSuccess');
  errEl.style.display = 'none'; okEl.style.display = 'none';
  const res = await apiPost('api/update_profile.php', { type: 'password', old_password: oldPwd, new_password: newPwd, new_password2: newPwd2 });
  if (res.success) {
    document.getElementById('oldPwd').value = '';
    document.getElementById('newPwd').value = '';
    document.getElementById('newPwd2').value = '';
    okEl.style.display = 'block';
    setTimeout(() => { okEl.style.display = 'none'; }, 3000);
  } else {
    const msg = res.errors ? Object.values(res.errors).join(', ') : (res.error || 'Ошибка');
    errEl.textContent = msg; errEl.style.display = 'block';
  }
}

/* ===== CONTACTS PAGE ===== */
function renderContacts() {
  document.getElementById('app').innerHTML = `
    <div class="page-banner page-banner--contacts">
      <div class="page-banner__bg"></div>
      <div class="page-banner__content"><h1 class="page-banner__title">Контакты</h1><p class="page-banner__sub">Мы всегда на связи</p></div>
    </div>
    <div class="contacts-grid">
      <div class="contact-info">
        <h2>О компании</h2>
        <p style="color:var(--text-muted);margin-bottom:24px;font-size:0.85rem;line-height:1.8;font-weight:300">DriveNow — сервис каршеринга нового поколения. Мы работаем с 2020 года и предоставляем доступные и удобные автомобили по всему городу.</p>
        <div class="contact-item"><div class="contact-item__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg></div><div class="contact-item__text"><strong>Адрес</strong>Москва, ул. Тверская, 12</div></div>
        <div class="contact-item"><div class="contact-item__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.01 1.18 2 2 0 012 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg></div><div class="contact-item__text"><strong>Телефон</strong>+7 (800) 555-35-35</div></div>
        <div class="contact-item"><div class="contact-item__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div><div class="contact-item__text"><strong>Email</strong>hello@drivenow.ru</div></div>
        <div class="contact-item"><div class="contact-item__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div><div class="contact-item__text"><strong>Режим работы</strong>Круглосуточно, 7 дней в неделю</div></div>
        <div id="leafletMap" style="height:260px;margin-top:20px;border:1px solid var(--border);overflow:hidden"></div>
      </div>
      <div class="contact-form">
        <h2>Обратная связь</h2>
        <div class="form-group"><label>Ваше имя</label><input type="text" id="contactName" placeholder="Иван Иванов" oninput="validateField(this,'name')" /><div class="field-error" id="err-contactName"></div></div>
        <div class="form-group"><label>Email</label><input type="email" id="contactEmail" placeholder="ivan@example.com" oninput="validateField(this,'email')" /><div class="field-error" id="err-contactEmail"></div></div>
        <div class="form-group"><label>Сообщение</label><textarea id="contactMsg" rows="4" placeholder="Ваш вопрос или предложение..." oninput="validateField(this,'message')"></textarea><div class="field-error" id="err-contactMsg"></div></div>
        <button class="btn btn-primary" onclick="submitContact()">Отправить</button>
        <div class="form-success" id="formSuccess">Сообщение отправлено. Мы свяжемся с вами в ближайшее время.</div>
      </div>
    </div>`;
  initPageBannerParallax();
  setTimeout(() => {
    if (typeof L === 'undefined') return;
    const map = L.map('leafletMap').setView([55.7558, 37.6173], 14);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap', maxZoom: 19 }).addTo(map);
    const icon = L.divIcon({ html: '<div style="width:10px;height:10px;background:var(--gold,#c9a84c);border-radius:50%;border:2px solid #fff;box-shadow:0 0 6px rgba(201,168,76,0.6)"></div>', className: '', iconSize: [10,10], iconAnchor: [5,5] });
    L.marker([55.7558, 37.6173], { icon }).addTo(map).bindPopup('<b>DriveNow</b><br>Москва, ул. Тверская, 12').openPopup();
    [[55.7620,37.6080],[55.7490,37.6300],[55.7530,37.5990]].forEach(c => L.marker(c, { icon }).addTo(map).bindPopup('Точка выдачи DriveNow'));
  }, 50);
}

function submitContact() {
  const nameEl = document.getElementById('contactName');
  const emailEl = document.getElementById('contactEmail');
  const msgEl = document.getElementById('contactMsg');
  if (!validateField(nameEl,'name') || !validateField(emailEl,'email') || !validateField(msgEl,'message')) return;
  const s = document.getElementById('formSuccess');
  s.style.display = 'block';
  nameEl.value = ''; emailEl.value = ''; msgEl.value = '';
  clearFieldError(nameEl); clearFieldError(emailEl); clearFieldError(msgEl);
  setTimeout(() => { s.style.display = 'none'; }, 4000);
}

/* ===== ROUTER ===== */
const routes = { home: renderHome, cars: renderCars, garage: renderGarage, stats: renderStats, contacts: renderContacts, settings: renderSettings };
const pathMap = { '/': 'home', '/cars': 'cars', '/garage': 'garage', '/stats': 'stats', '/contacts': 'contacts', '/settings': 'settings' };

function navigate(page, pushState = true) {
  clearInterval(sliderTimer);
  if (window._parallaxHandler) { window.removeEventListener('scroll', window._parallaxHandler); window._parallaxHandler = null; }
  if (window._bannerParallaxHandler) { window.removeEventListener('scroll', window._bannerParallaxHandler); window._bannerParallaxHandler = null; }
  const pathRev = { home:'/', cars:'/cars', garage:'/garage', stats:'/stats', contacts:'/contacts', settings:'/settings' };
  if (pushState) history.pushState({ page }, '', pathRev[page] || '/');
  document.querySelectorAll('.nav-link').forEach(a => a.classList.toggle('active', a.dataset.page === page));
  (routes[page] || renderHome)();
  requestAnimationFrame(() => requestAnimationFrame(observeReveal));
}

window.addEventListener('popstate', e => { navigate((e.state && e.state.page) || pathMap[location.pathname] || 'home', false); });
document.querySelectorAll('.nav-link').forEach(a => { a.addEventListener('click', e => { e.preventDefault(); navigate(a.dataset.page); }); });

/* ===== VALIDATION ===== */
function validateField(el, type) {
  const val = el.value.trim();
  const errEl = document.getElementById('err-' + el.id);
  let msg = '';
  switch (type) {
    case 'name':    if (!val) msg='Введите имя'; else if (val.length<2) msg='Минимум 2 символа'; break;
    case 'email':   if (!val) msg='Введите email'; else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) msg='Некорректный email'; break;
    case 'message': if (!val) msg='Введите сообщение'; else if (val.length<10) msg='Минимум 10 символов'; break;
    case 'editName':  if (!val) msg='Введите название'; else if (val.length<2) msg='Минимум 2 символа'; break;
    case 'editHours': { const n=Number(el.value); if (!el.value) msg='Введите количество часов'; else if (!Number.isInteger(n)||n<1) msg='Минимум 1 час'; else if (n>720) msg='Максимум 720 часов'; break; }
  }
  if (errEl) { errEl.textContent = msg; errEl.style.display = msg ? 'block' : 'none'; }
  el.classList.toggle('input-invalid', !!msg);
  el.classList.toggle('input-valid', !msg);
  return !msg;
}
function clearFieldError(el) {
  const errEl = document.getElementById('err-' + el.id);
  if (errEl) { errEl.textContent = ''; errEl.style.display = 'none'; }
  el.classList.remove('input-invalid', 'input-valid');
}

/* ===== PAGE BANNER PARALLAX ===== */
function initPageBannerParallax() {
  const banner = document.querySelector('.page-banner');
  if (!banner) return;
  const bg = banner.querySelector('.page-banner__bg');
  if (!bg) return;
  const handler = () => { bg.style.transform = `translateY(${-banner.getBoundingClientRect().top * 0.35}px)`; };
  window.addEventListener('scroll', handler, { passive: true });
  window._bannerParallaxHandler = handler;
}

/* ===== RIPPLE ===== */
document.addEventListener('click', e => {
  const btn = e.target.closest('.btn, .auth-submit, .auth-social-btn');
  if (!btn) return;
  const r = document.createElement('span'); r.className = 'ripple';
  const rect = btn.getBoundingClientRect(), size = Math.max(rect.width, rect.height);
  r.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX-rect.left-size/2}px;top:${e.clientY-rect.top-size/2}px`;
  btn.appendChild(r); r.addEventListener('animationend', () => r.remove());
});

/* ===== INTERSECTION OBSERVER ===== */
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); revealObserver.unobserve(e.target); } });
}, { threshold: 0.1 });
function observeReveal() {
  document.querySelectorAll('.car-card,.feature-card,.promo-card,.stat-card,.garage-card,.home-counter').forEach(el => { el.classList.add('reveal'); revealObserver.observe(el); });
}

/* ===== PARTICLES ===== */
function spawnParticles(container) {
  for (let i = 0; i < 18; i++) {
    const p = document.createElement('div'); p.className = 'particle';
    const size = Math.random()*18+6;
    p.style.cssText = `width:${size}px;height:${size}px;left:${Math.random()*100}%;bottom:${Math.random()*-20}%;animation-duration:${Math.random()*12+8}s;animation-delay:${Math.random()*8}s;opacity:${Math.random()*0.5+0.1};`;
    container.appendChild(p);
  }
}

/* ===== AUTH ===== */
const authOverlay = document.getElementById('authOverlay');
const authBtn = document.getElementById('authBtn');
const authClose = document.getElementById('authClose');

function openAuth(tab = 'login') { renderAuthContent(tab); authOverlay.classList.add('open'); }
function closeAuth() { authOverlay.classList.remove('open'); }

authBtn.addEventListener('click', () => { if (currentUser) openUserMenu(); else openAuth('login'); });
authClose.addEventListener('click', closeAuth);
authOverlay.addEventListener('click', e => { if (e.target === authOverlay) closeAuth(); });
document.querySelectorAll('.auth-tab').forEach(t => {
  t.addEventListener('click', () => { document.querySelectorAll('.auth-tab').forEach(x => x.classList.remove('active')); t.classList.add('active'); renderAuthContent(t.dataset.tab); });
});

function renderAuthContent(tab) {
  document.querySelectorAll('.auth-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
  const el = document.getElementById('authContent');
  if (tab === 'login') {
    el.innerHTML = `
      <div class="auth-logo"><div class="logo-emblem" style="width:44px;height:44px;margin:0 auto 16px"><div class="logo-emblem-inner">DN</div></div></div>
      <div class="auth-title">С возвращением</div>
      <div class="auth-sub">Войдите, чтобы продолжить</div>
      <div class="auth-error" id="authError"></div>
      <form class="auth-form" onsubmit="submitLogin(event)">
        <div class="form-group"><label>Логин</label><div class="input-wrap"><span class="input-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></span><input type="text" id="loginUsername" placeholder="username" required autocomplete="username" /></div></div>
        <div class="form-group"><label>Пароль</label><div class="input-wrap"><span class="input-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg></span><input type="password" id="loginPwd" placeholder="••••••••" required autocomplete="current-password" /></div></div>
        <label style="display:flex;align-items:center;gap:8px;font-size:0.85rem;margin-bottom:16px;cursor:pointer"><input type="checkbox" id="loginRemember" /> Запомнить меня</label>
        <button type="submit" class="auth-submit">Войти</button>
      </form>
      <div class="auth-footer">Нет аккаунта? <a onclick="renderAuthContent('register')">Зарегистрироваться</a></div>`;
  } else {
    el.innerHTML = `
      <div class="auth-logo"><div class="logo-emblem" style="width:44px;height:44px;margin:0 auto 16px"><div class="logo-emblem-inner">DN</div></div></div>
      <div class="auth-title">Создать аккаунт</div>
      <div class="auth-sub">Присоединяйтесь к DriveNow</div>
      <div class="auth-error" id="authError"></div>
      <form class="auth-form" onsubmit="submitRegister(event)">
        <div class="form-group"><label>Логин</label><div class="input-wrap"><span class="input-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></span><input type="text" id="regUsername" placeholder="username" required autocomplete="username" /></div></div>
        <div class="form-group"><label>Имя</label><div class="input-wrap"><span class="input-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></span><input type="text" id="regName" placeholder="Иван Иванов" required autocomplete="name" /></div></div>
        <div class="form-group"><label>Email</label><div class="input-wrap"><span class="input-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></span><input type="email" id="regEmail" placeholder="ivan@example.com" required autocomplete="email" /></div></div>
        <div class="form-group"><label>Пароль</label><div class="input-wrap"><span class="input-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg></span><input type="password" id="regPwd" placeholder="Минимум 6 символов" required autocomplete="new-password" oninput="checkPwdStrength(this.value)" /></div><div class="pwd-strength" id="pwdStrength"><div class="pwd-bar" id="pb1"></div><div class="pwd-bar" id="pb2"></div><div class="pwd-bar" id="pb3"></div></div><div class="pwd-label" id="pwdLabel"></div></div>
        <div class="form-group"><label>Повторите пароль</label><div class="input-wrap"><span class="input-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg></span><input type="password" id="regPwd2" placeholder="••••••••" required autocomplete="new-password" /></div></div>
        <button type="submit" class="auth-submit">Зарегистрироваться</button>
      </form>
      <div class="auth-footer">Уже есть аккаунт? <a onclick="renderAuthContent('login')">Войти</a></div>`;
  }
}

function checkPwdStrength(val) {
  const bars = [document.getElementById('pb1'),document.getElementById('pb2'),document.getElementById('pb3')];
  const label = document.getElementById('pwdLabel');
  if (!bars[0]) return;
  bars.forEach(b => { b.className = 'pwd-bar'; });
  if (!val) { label.textContent = ''; return; }
  let score = 0;
  if (val.length >= 6) score++;
  if (val.length >= 10) score++;
  if (/[A-Z]/.test(val) && /[0-9]/.test(val)) score++;
  const levels = [['weak','weak','weak'],['weak','medium','medium'],['strong','strong','strong']];
  const names = ['Слабый','Средний','Надёжный'];
  (levels[Math.max(0,score-1)]||[]).forEach((cls,i) => { if (i<score) bars[i].classList.add(cls); });
  label.textContent = names[score-1] || '';
}

function showAuthError(msg) {
  const el = document.getElementById('authError');
  if (!el) return;
  el.textContent = msg; el.style.display = 'block';
  el.style.animation = 'none';
  requestAnimationFrame(() => { el.style.animation = 'pageFadeIn 0.3s ease'; });
}

async function submitLogin(e) {
  e.preventDefault();
  const usernameEl = document.getElementById('loginUsername');
  const pwdEl = document.getElementById('loginPwd');
  const remember = document.getElementById('loginRemember').checked;
  if (!usernameEl.value.trim()) { setInputError(usernameEl, 'Введите логин'); return; }
  if (!pwdEl.value) { setInputError(pwdEl, 'Введите пароль'); return; }
  const res = await apiPost('api/login.php', { username: usernameEl.value.trim(), password: pwdEl.value, remember });
  if (res.success) {
    await loginUser(res.user);
  } else {
    showAuthError(res.error || 'Ошибка входа');
  }
}

async function submitRegister(e) {
  e.preventDefault();
  const usernameEl = document.getElementById('regUsername');
  const nameEl = document.getElementById('regName');
  const emailEl = document.getElementById('regEmail');
  const pwdEl = document.getElementById('regPwd');
  const pwd2El = document.getElementById('regPwd2');
  const res = await apiPost('api/register.php', {
    username: usernameEl.value.trim(), full_name: nameEl.value.trim(),
    email: emailEl.value.trim(), password: pwdEl.value, password2: pwd2El.value
  });
  if (res.success) {
    await loginUser(res.user);
  } else if (res.errors) {
    const first = Object.values(res.errors)[0];
    showAuthError(first);
  } else {
    showAuthError(res.error || 'Ошибка регистрации');
  }
}

function setInputError(input, msg) {
  input.style.borderColor = '#ef4444'; input.style.boxShadow = '0 0 0 3px rgba(239,68,68,0.15)';
  let err = input.parentElement.querySelector('.auth-field-err');
  if (!err) { err = document.createElement('div'); err.className = 'auth-field-err'; input.parentElement.appendChild(err); }
  err.textContent = msg;
}
function clearInputError(input) {
  input.style.borderColor = ''; input.style.boxShadow = '';
  const err = input.parentElement.querySelector('.auth-field-err');
  if (err) err.remove();
}

async function loginUser(user) {
  currentUser = user;
  // Загружаем гараж пользователя
  const garageRes = await apiGet('api/get_garage.php');
  if (garageRes.success) myCars = garageRes.garage;
  closeAuth();
  updateAuthBtn();
  showToast(`Добро пожаловать, ${user.full_name.split(' ')[0]}! 👋`);
  navigate('home', false);
  renderHome();
}

async function logoutUser() {
  await apiPost('api/logout.php', {});
  currentUser = null;
  myCars = [];
  updateAuthBtn();
  showToast('Вы вышли из аккаунта');
  navigate('home');
}

function updateAuthBtn() {
  if (currentUser) {
    authBtn.innerHTML = `<span class="user-avatar">${currentUser.full_name.charAt(0).toUpperCase()}</span>${currentUser.full_name.split(' ')[0]}`;
    authBtn.classList.add('logged-in');
  } else {
    authBtn.innerHTML = '👤 Войти';
    authBtn.classList.remove('logged-in');
  }
}

function openUserMenu() {
  modal.open(`
    <div style="text-align:center;padding:8px 0 24px">
      <div class="user-avatar" style="width:52px;height:52px;font-size:1.2rem;margin:0 auto 12px">${currentUser.full_name.charAt(0).toUpperCase()}</div>
      <div style="font-family:var(--font-display);font-size:1.1rem;font-weight:400;letter-spacing:1px">${currentUser.full_name}</div>
      <div style="font-size:0.75rem;color:var(--text-muted);margin-top:4px;letter-spacing:0.5px">${currentUser.email}</div>
    </div>
    <div class="modal-actions" style="flex-direction:column">
      <button class="btn btn-secondary" onclick="modal.close();navigate('garage')">Мой гараж</button>
      <button class="btn btn-secondary" onclick="modal.close();navigate('stats')">Статистика</button>
      <button class="btn btn-secondary" onclick="modal.close();navigate('settings')">Настройки</button>
      <button class="btn btn-danger" onclick="modal.close();logoutUser()">Выйти</button>
    </div>`);
}

/* ===== INIT ===== */
new ThemeSwitcher();

async function init() {
  try {
    // Загружаем список машин
    const carsRes = await apiGet('api/get_cars.php');
    if (carsRes && carsRes.success) carsAvailable = carsRes.cars;
  } catch (e) {
    console.warn('Не удалось загрузить автомобили:', e);
  }

  try {
    // Проверяем сессию
    const userRes = await apiGet('api/get_user.php');
    if (userRes && userRes.success && userRes.user) {
      currentUser = userRes.user;
      const garageRes = await apiGet('api/get_garage.php');
      if (garageRes && garageRes.success) myCars = garageRes.garage;
    }
  } catch (e) {
    console.warn('Не удалось проверить сессию:', e);
  }

  updateAuthBtn();
  const initPage = pathMap[location.pathname] || 'home';
  navigate(initPage, false);
}

init();
