<?php
require_once 'functions.php';
checkAuth();

$user_login = $_SESSION['user_login'];
$notes = getUserNotes($user_login);

// DEBUG — удали после исправления
$notesDir = __DIR__ . '/data/notes/';
$allFiles = glob($notesDir . '*.txt');
error_log("DEBUG notes.php: login=" . var_export($user_login, true) . ", files=" . implode(',', $allFiles ?? []) . ", found=" . count($notes));

// Поиск
$search = trim($_GET['search'] ?? '');
if ($search) {
    $notes = array_filter($notes, function($note) use ($search) {
        return stripos($note['title'], $search) !== false;
    });
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои заметки - Личный блокнот</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body class="theme-<?php 
    $users = getUsers();
    echo $users[$user_login]['theme'];
?>">
    <nav class="navbar">
        <div class="nav-container">
            <a href="index.php" class="nav-brand">📓 Личный блокнот</a>
            <div class="nav-menu">
                <a href="notes.php" class="nav-link active">📝 Заметки</a>
                <a href="settings.php" class="nav-link">⚙️ Настройки</a>
                <a href="logout.php" class="nav-link">🚪 Выход</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="page-header">
            <h1>Мои заметки</h1>
            <a href="note_add.php" class="btn btn-primary">➕ Создать заметку</a>
        </div>
        
        <div class="search-bar">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Поиск по заголовку..." 
                       value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="btn">🔍 Найти</button>
                <?php if ($search): ?>
                    <a href="notes.php" class="btn">Сбросить</a>
                <?php endif; ?>
            </form>
        </div>
        
        <?php if (empty($notes)): ?>
            <div class="empty-state">
                <p><?= $search ? 'Заметки не найдены' : 'У вас пока нет заметок' ?></p>
                <?php if (!$search): ?>
                    <a href="note_add.php" class="btn btn-primary">Создать первую заметку</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="notes-grid">
                <?php foreach ($notes as $note): ?>
                    <div class="note-card">
                        <div class="note-header">
                            <h3><?= htmlspecialchars($note['title']) ?></h3>
                            <div class="note-actions">
                                <a href="note_edit.php?id=<?= $note['id'] ?>" class="btn-small">✏️</a>
                                <a href="note_delete.php?id=<?= $note['id'] ?>" 
                                   class="btn-small danger" 
                                   onclick="return confirm('Удалить заметку?')">🗑️</a>
                            </div>
                        </div>
                        <div class="note-preview">
                            <?= htmlspecialchars(mb_substr($note['text'], 0, 150)) ?>
                            <?= mb_strlen($note['text']) > 150 ? '...' : '' ?>
                        </div>
                        <div class="note-footer">
                            <span>Создана: <?= date('d.m.Y H:i', strtotime($note['created'])) ?></span>
                            <span>Обновлена: <?= date('d.m.Y H:i', strtotime($note['updated'])) ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>