<?php
require_once 'functions.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    
    // Валидация
    if (!validateLogin($login)) {
        $error = 'Логин должен содержать 3-20 символов (буквы, цифры, _)';
    } elseif (!validatePassword($password)) {
        $error = 'Пароль должен быть не менее 6 символов';
    } elseif ($password !== $confirm_password) {
        $error = 'Пароли не совпадают';
    } elseif (!validateName($name)) {
        $error = 'Имя должно содержать только буквы (2-50 символов)';
    } elseif (!validateEmail($email)) {
        $error = 'Введите корректный email';
    } else {
        // Проверка существования пользователя
        $users = getUsers();
        if (isset($users[$login])) {
            $error = 'Пользователь с таким логином уже существует';
        } else {
            // Сохранение пользователя
            $users[$login] = [
                'login' => $login,
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'name' => $name,
                'email' => $email,
                'theme' => 'light',
                'reg_date' => date('Y-m-d H:i:s')
            ];
            saveUsers($users);
            
            // Создание папки для заметок пользователя
            $notesDir = __DIR__ . '/data/notes/';
            if (!is_dir($notesDir)) {
                mkdir($notesDir, 0777, true);
            }
            
            $success = 'Регистрация успешна! Теперь вы можете войти.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация - Личный блокнот</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h1>Регистрация</h1>
            
            <?php if ($error): ?>
                <?= showMessage($error, 'error') ?>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <?= showMessage($success, 'success') ?>
                <p><a href="login.php" class="btn">Войти</a></p>
            <?php else: ?>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="login">Логин:</label>
                        <input type="text" id="login" name="login" required 
                               value="<?= htmlspecialchars($_POST['login'] ?? '') ?>">
                        <small>3-20 символов, буквы, цифры, подчеркивание</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Пароль:</label>
                        <input type="password" id="password" name="password" required>
                        <small>Не менее 6 символов</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Подтверждение пароля:</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="name">Имя:</label>
                        <input type="text" id="name" name="name" required 
                               value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
                        <small>Только буквы, 2-50 символов</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required 
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
                </form>
                
                <p class="text-center">Уже есть аккаунт? <a href="login.php">Войти</a></p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>