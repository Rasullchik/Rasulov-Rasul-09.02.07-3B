<?php
require_once 'functions.php';
checkAuth();

$user_login = $_SESSION['user_login'];
$id = (int)($_GET['id'] ?? 0);

// Проверка владельца заметки
if (checkNoteOwner($user_login, $id)) {
    $filepath = __DIR__ . "/data/notes/{$user_login}_{$id}.txt";
    unlink($filepath);
}

header('Location: notes.php');
exit();
?>