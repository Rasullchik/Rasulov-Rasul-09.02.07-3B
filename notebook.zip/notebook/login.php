<?php
require_once 'functions.php';

if (isset($_SESSION['user_login'])) {
    header('Location: index.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);
    
    $users = getUsers();
    
    if (isset($users[$login]) && password_verify($password, $users[$login]['password'])) {
        $_SESSION['user_login'] = $login;
        
        if ($remember) {
            setcookie('remember_me', '1', time() + 30 * 24 * 3600, '/');
            setcookie('user_login', $login, time() + 30 * 24 * 3600, '/');
        }
        
        header('Location: index.php');
        exit();
    } else {
        $error = 'Неверный логин или пароль';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход - Личный блокнот</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h1>Вход в систему</h1>
            
            <?php if ($error): ?>
                <?= showMessage($error, 'error') ?>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="login">Логин:</label>
                    <input type="text" id="login" name="login" required 
                           value="<?= htmlspecialchars($_POST['login'] ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Пароль:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <div class="form-group">
                    <label class="checkbox">
                        <input type="checkbox" name="remember"> Запомнить меня
                    </label>
                </div>
                
                <button type="submit" class="btn btn-primary">Войти</button>
            </form>
            
            <p class="text-center">Нет аккаунта? <a href="register.php">Зарегистрироваться</a></p>
        </div>
    </div>
</body>
</html>