<?php
require_once 'functions.php';
checkAuth();

$user_login = $_SESSION['user_login'];
$users = getUsers();
$user = $users[$user_login];
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $theme = $_POST['theme'] ?? 'light';
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    
    if (!validateName($name)) {
        $error = 'Имя должно содержать только буквы (2-50 символов)';
    } elseif (!validateEmail($email)) {
        $error = 'Введите корректный email';
    } else {
        // Обновление данных пользователя
        $users[$user_login]['name'] = $name;
        $users[$user_login]['email'] = $email;
        $users[$user_login]['theme'] = $theme;
        saveUsers($users);
        
        setcookie('user_theme', $theme, time() + 365 * 24 * 3600, '/');
        $success = 'Настройки успешно сохранены!';
        
        // Обновление данных текущего пользователя
        $user = $users[$user_login];
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Настройки - Личный блокнот</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body class="theme-<?= $user['theme'] ?>">
    <nav class="navbar">
        <div class="nav-container">
            <a href="index.php" class="nav-brand">📓 Личный блокнот</a>
            <div class="nav-menu">
                <a href="notes.php" class="nav-link">📝 Заметки</a>
                <a href="settings.php" class="nav-link active">⚙️ Настройки</a>
                <a href="logout.php" class="nav-link">🚪 Выход</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <div class="form-container">
            <h1>Настройки профиля</h1>
            
            <?php if ($success): ?>
                <?= showMessage($success, 'success') ?>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <?= showMessage($error, 'error') ?>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label>Тема оформления:</label>
                    <select name="theme">
                        <option value="light" <?= $user['theme'] == 'light' ? 'selected' : '' ?>>Светлая</option>
                        <option value="dark" <?= $user['theme'] == 'dark' ? 'selected' : '' ?>>Темная</option>
                        <option value="blue" <?= $user['theme'] == 'blue' ? 'selected' : '' ?>>Синяя</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="name">Отображаемое имя:</label>
                    <input type="text" id="name" name="name" required 
                           value="<?= htmlspecialchars($user['name']) ?>">
                    <small>Только буквы, 2-50 символов</small>
                </div>
                
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required 
                           value="<?= htmlspecialchars($user['email']) ?>">
                </div>
                
                <div class="form-group">
                    <label>Логин:</label>
                    <input type="text" value="<?= htmlspecialchars($user['login']) ?>" disabled>
                    <small>Логин нельзя изменить</small>
                </div>
                
                <div class="form-group">
                    <label>Дата регистрации:</label>
                    <input type="text" value="<?= date('d.m.Y H:i', strtotime($user['reg_date'])) ?>" disabled>
                </div>
                
                <button type="submit" class="btn btn-primary">💾 Сохранить настройки</button>
            </form>
        </div>
    </div>
</body>
</html>