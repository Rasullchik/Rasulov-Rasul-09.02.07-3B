<?php
session_start();

// Функция для проверки авторизации
function checkAuth() {
    if (!isset($_SESSION['user_login'])) {
        // Проверка cookie "запомнить меня"
        if (isset($_COOKIE['remember_me']) && isset($_COOKIE['user_login'])) {
            $_SESSION['user_login'] = $_COOKIE['user_login'];
            return true;
        }
        header('Location: login.php');
        exit();
    }
    return true;
}

// Функция для получения всех пользователей
function getUsers() {
    $users = [];
    $file = __DIR__ . '/data/users.txt';
    if (file_exists($file)) {
        $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $line = trim($line);
            // Поддержка обоих форматов: старый '\' и новый '|'
            $sep = strpos($line, '|') !== false ? '|' : '\\';
            $data = explode($sep, $line);
            if (count($data) >= 5) {
                $login = trim($data[0]);
                $users[$login] = [
                    'login'    => $login,
                    'password' => trim($data[1]),
                    'name'     => trim($data[2]),
                    'email'    => trim($data[3]),
                    'theme'    => trim($data[4] ?? 'light'),
                    'reg_date' => trim($data[5] ?? date('Y-m-d H:i:s'))
                ];
            }
        }
    }
    return $users;
}

// Функция для сохранения пользователей
function saveUsers($users) {
    $file = __DIR__ . '/data/users.txt';
    $lines = [];
    foreach ($users as $user) {
        $lines[] = implode('|', [
            trim($user['login']),
            trim($user['password']),
            trim($user['name']),
            trim($user['email']),
            trim($user['theme']),
            trim($user['reg_date'])
        ]);
    }
    file_put_contents($file, implode("\n", $lines));
}

// Функция для генерации ID заметки
function getNextNoteId($login) {
    $notesDir = __DIR__ . "/data/notes/";
    if (!is_dir($notesDir)) {
        mkdir($notesDir, 0777, true);
    }
    $pattern = $notesDir . $login . "_*.txt";
    $files = glob($pattern);
    $maxId = 0;
    foreach ($files as $file) {
        $basename = str_replace('\\', '/', $file);
        preg_match('/' . preg_quote($login, '/') . '_(\d+)\.txt$/', $basename, $matches);
        if (isset($matches[1]) && (int)$matches[1] > $maxId) {
            $maxId = (int)$matches[1];
        }
    }
    return $maxId + 1;
}

// Функция для парсинга файла заметки
function parseNoteFile($filepath) {
    if (!file_exists($filepath)) {
        return null;
    }
    
    $content = file_get_contents($filepath);
    
    // Разбираем заголовки
    preg_match('/title: ([^\n]*)/', $content, $titleMatch);
    preg_match('/created: ([^\n]*)/', $content, $createdMatch);
    preg_match('/updated: ([^\n]*)/', $content, $updatedMatch);
    
    // Получаем текст после разделителя
    $text = preg_replace('/.*---\n/s', '', $content);
    
    return [
        'title' => trim($titleMatch[1] ?? ''),
        'created' => trim($createdMatch[1] ?? ''),
        'updated' => trim($updatedMatch[1] ?? ''),
        'text' => trim($text)
    ];
}

// Функция для сохранения файла заметки
function saveNoteFile($login, $id, $title, $text, $isNew = true) {
    $filepath = __DIR__ . "/data/notes/{$login}_{$id}.txt";
    $now = date('Y-m-d H:i:s');
    
    if ($isNew) {
        $content = "title: $title\n";
        $content .= "created: $now\n";
        $content .= "updated: $now\n";
        $content .= "---\n";
        $content .= $text;
    } else {
        // Для редактирования - сохраняем created из старого файла
        $oldNote = parseNoteFile($filepath);
        $created = $oldNote['created'] ?? $now;
        $content = "title: $title\n";
        $content .= "created: $created\n";
        $content .= "updated: $now\n";
        $content .= "---\n";
        $content .= $text;
    }
    
    return file_put_contents($filepath, $content);
}

// Функция для получения всех заметок пользователя
function getUserNotes($login) {
    $notesDir = __DIR__ . "/data/notes/";
    $pattern = $notesDir . $login . "_*.txt";
    $files = glob($pattern);
    $notes = [];
    
    foreach ($files as $file) {
        $basename = str_replace('\\', '/', $file);
        preg_match('/' . preg_quote($login, '/') . '_(\d+)\.txt$/', $basename, $matches);
        if (isset($matches[1])) {
            $note = parseNoteFile($file);
            if ($note) {
                $note['id'] = (int)$matches[1];
                $notes[] = $note;
            }
        }
    }
    
    // Сортировка по дате изменения (новые сверху)
    usort($notes, function($a, $b) {
        return strtotime($b['updated']) - strtotime($a['updated']);
    });
    
    return $notes;
}

// Функция для отображения сообщений
function showMessage($msg, $type = 'error') {
    $class = $type === 'error' ? 'error' : 'success';
    return "<div class='message $class'>$msg</div>";
}

// Функция для валидации логина
function validateLogin($login) {
    return preg_match('/^[a-zA-Z0-9_]{3,20}$/', $login);
}

// Функция для валидации пароля
function validatePassword($password) {
    return strlen($password) >= 6;
}

// Функция для валидации имени
function validateName($name) {
    return preg_match('/^[a-zA-Zа-яА-Я]{2,50}$/u', $name);
}

// Функция для валидации email
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Функция для валидации заголовка
function validateTitle($title) {
    $len = mb_strlen($title);
    return $len >= 3 && $len <= 100;
}

// Функция для проверки владельца заметки
function checkNoteOwner($login, $id) {
    $filepath = __DIR__ . "/data/notes/{$login}_{$id}.txt";
    return file_exists($filepath);
}
?>